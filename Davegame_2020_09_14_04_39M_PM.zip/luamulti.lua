

local threacode = [[

]]


function create_enviro_thread(townblocklist, left, right, chunksize)
  
end
