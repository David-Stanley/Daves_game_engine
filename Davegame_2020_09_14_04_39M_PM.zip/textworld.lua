function drawtextworld()
  love.graphics.print(textworld_text, gamewindow.width/2-50, gamewindow.height/10+(50*1), 0, 2, 2)
  love.graphics.print(whatswritten, gamewindow.width/2-50, gamewindow.height/10+(50*3), 0, 2, 2)
end